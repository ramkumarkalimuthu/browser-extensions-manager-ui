document.addEventListener("DOMContentLoaded", () => {
    // Prevent refetch if already stored
    if (!localStorage.getItem("manager")) {
      fetch("data.json")
        .then(res => res.json())
        .then(data => {
          localStorage.setItem("manager", JSON.stringify(data));
          console.log("JSON stored in localStorage");
        })
        .catch(err => console.error("JSON load error:", err));
    } else {
      console.log("JSON already exists in localStorage");
    }
  });
  