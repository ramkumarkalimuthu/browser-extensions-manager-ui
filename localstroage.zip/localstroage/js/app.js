let darkmode = localStorage.getItem('darkmode')
const themeSwitch = document.getElementById('theme-toggle')

const enableDarkmode = () => {
  document.body.classList.add('darkmode')
  localStorage.setItem('darkmode', 'active')
}

const disableDarkmode = () => {
  document.body.classList.remove('darkmode')
  localStorage.setItem('darkmode', null)
}

if(darkmode === "active") enableDarkmode()

{
  themeSwitch.addEventListener("click", () => {
    darkmode = localStorage.getItem('darkmode')
    darkmode !== "active" ? enableDarkmode() : disableDarkmode()
  });
}
/*document.onkeydown = function(e) {
  if (KeyboardEvent.keyCode == 123) { return false; } // Disable F12
  if (e.ctrlKey && e.shiftKey && KeyboardEvent.keyCode == 'I'.charCodeAt(0)) { return false; } // Disable Ctrl+Shift+I
  if (e.ctrlKey && KeyboardEvent.keyCode == 'U'.charCodeAt(0)) { return false; } // Disable Ctrl+U
}*/
const carddata = document.getElementById('card-data');  
const buttons = document.querySelectorAll(".filters button");

loadStoredData();
 document.addEventListener("DOMContentLoaded", () => {
  // Prevent refetch if already stored
if (!localStorage.getItem("manager")) {
    fetch("data.json")
      .then(res => res.json())
      .then(data => {
        localStorage.setItem("manager", JSON.stringify(data));
        console.log("JSON stored in localStorage");
        loadStoredData();
      })
      .catch(err => console.error("JSON load error:", err));
  } else {
    console.log("JSON already exists in localStorage");
  }
});
// Swith toogle update
function updateToggle(idx,checked)
{
   const storedData = JSON.parse(localStorage.getItem("manager"));
    storedData[idx].isActive = checked;
    console.log("updated")
    localStorage.setItem("manager", JSON.stringify(storedData));
    loadStoredData();
}


// delete data
function deletaData() {
  if (confirm("Are You Sure to Delete ?")) {
    const index = this.dataset.index;
    const storedData = JSON.parse(localStorage.getItem("manager")) || [];
    storedData.splice(index, 1);
    localStorage.setItem("manager", JSON.stringify(storedData));
    loadStoredData();
  }
}


// get data
function loadStoredData() {
  const storedData = JSON.parse(localStorage.getItem("manager")) || [];  
carddata.innerHTML = "";
storedData.forEach(function (data, index){
  console.log(data);
  carddata.innerHTML += `
                    <article class="card">
                    <div class="card-header">
                      <div class="icon pink"><img src="${data.logo}" alt="icon" class="card__icon" /></div>
                      <div class="content">
                        <h3>${data.name}</h3>
                        <p>${data.description}</p>
                      </div>
                    </div>

                    <div class="card-footer">
                      <button class="remove" data-index="${index}">Remove</button>
                      <label class="switch">
                        <input data-index="${index}" type="checkbox" id="toggle" ${data.isActive ? "checked" : ""}>
                        <span></span>
                      </label>
                    </div>
                  </article>
                    `;
   
});

                const delButtons = document.querySelectorAll(".remove");
                    delButtons.forEach((btn) => {
                      btn.addEventListener("click", deletaData);
                    });  

                          const switched = document.querySelectorAll(".switch input");
                          switched.forEach((input) => {
                            input.addEventListener("change", (e) =>{

                              const idx = e.target.getAttribute("data-index");
                              const checked = e.target.checked;
                              updateToggle(idx,checked)
                              //console.log(checked);
                            

                            });

  
});  

   
}

let currentfilter = "all";


function filteredData(type){

}



  